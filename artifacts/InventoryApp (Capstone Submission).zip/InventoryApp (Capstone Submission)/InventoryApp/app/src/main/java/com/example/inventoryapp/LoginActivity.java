
package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Handles the login screen and account creation.
 * Uses UserRepository to manage user accounts and check login credentials.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etPassword;

    private UserRepository userRepository;

    // Sets up the login screen and connects the login and account creation buttons.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);

        Button btnLogin =
                findViewById(R.id.btnLogin);

        Button btnCreateAccount =
                findViewById(R.id.btnCreateAccount);

        userRepository =
                new UserRepository(
                        new DatabaseHelper(this)
                );

        btnCreateAccount.setOnClickListener(
                view -> createAccount()
        );

        btnLogin.setOnClickListener(
                view -> login()
        );
    }

    // Checks basic requirements before creating a new account.
    private void createAccount() {

        String username =
                etUsername.getText().toString().trim();

        String password =
                etPassword.getText().toString();

        if (username.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter a username.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (password.length() < 6) {

            Toast.makeText(
                    this,
                    "Password must contain at least 6 characters.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        try {

            boolean created =
                    userRepository.createUser(
                            username,
                            password
                    );

            if (created) {

                Toast.makeText(
                        this,
                        "Account created successfully.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "That username is already in use.",
                        Toast.LENGTH_LONG
                ).show();
            }

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Account could not be created.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // Authentication is handled by the repository instead of this Activity.
    private void login() {

        String username =
                etUsername.getText().toString().trim();

        String password =
                etPassword.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter your username and password.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        try {

            if (userRepository.authenticate(
                    username,
                    password
            )) {

                Toast.makeText(
                        this,
                        "Login successful.",
                        Toast.LENGTH_SHORT
                ).show();

                Intent intent =
                        new Intent(
                                this,
                                MainActivity.class
                        );

                startActivity(intent);

                // Prevents Back from returning to the completed login screen.
                finish();

            } else {

                Toast.makeText(
                        this,
                        "Invalid username or password.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Login could not be completed.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
