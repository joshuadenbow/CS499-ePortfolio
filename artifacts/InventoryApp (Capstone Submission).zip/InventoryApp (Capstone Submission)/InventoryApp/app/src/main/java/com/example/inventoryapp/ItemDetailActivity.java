
package com.example.inventoryapp;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Handles the item details screen where users can edit or delete items.
 * Also allows users to view an item's transaction history.
 */
public class ItemDetailActivity extends AppCompatActivity {

    private InventoryService inventoryService;

    private ReportRepository reportRepository;

    private long itemId;

    private EditText etName;
    private EditText etQuantity;
    private EditText etPrice;
    private EditText etCategory;

    private EditText etThreshold;

    // Sets up the screen, connects the buttons, and loads the selected item.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        DatabaseHelper databaseHelper =
                new DatabaseHelper(this);

        reportRepository = new ReportRepository(databaseHelper);

        InventoryRepository repository =
                new InventoryRepository(databaseHelper);

        inventoryService =
                new InventoryService(repository);

        itemId =
                getIntent().getLongExtra(
                        "item_id",
                        -1
                );

        etName =
                findViewById(R.id.etDetailName);

        etQuantity =
                findViewById(R.id.etDetailQuantity);

        etPrice =
                findViewById(R.id.etDetailPrice);

        etCategory =
                findViewById(R.id.etDetailCategory);

        etThreshold =
                findViewById(R.id.etDetailThreshold);

        findViewById(R.id.btnSaveItem)
                .setOnClickListener(
                        view -> saveItem()
                );

        findViewById(R.id.btnDeleteItem)
                .setOnClickListener(
                        view -> confirmDelete()
                );

        findViewById(R.id.btnCancel)
                .setOnClickListener(
                        view -> finish()
                );

        findViewById(R.id.btnViewHistory)
                .setOnClickListener(view -> showItemHistory());

        loadItem();
    }

    // Loads the model through the service instead of querying SQLite here.
    private void loadItem() {

        InventoryItem item =
                inventoryService.getItem(itemId);

        if (item == null) {

            Toast.makeText(
                    this,
                    "Item could not be found.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        etName.setText(
                item.getName()
        );

        etQuantity.setText(
                String.valueOf(item.getQuantity())
        );

        etPrice.setText(
                String.valueOf(item.getPrice())
        );

        etCategory.setText(
                item.getCategory()
        );

        etThreshold.setText(
                String.valueOf(
                        item.getReorderThreshold()
                )
        );
    }

    // Validates the edited information before saving changes to the item.
    private void saveItem() {

        String name =
                etName.getText().toString();

        String quantity =
                etQuantity.getText().toString();

        String price =
                etPrice.getText().toString();

        String category =
                etCategory.getText().toString();

        String threshold =
                etThreshold.getText().toString();

        String validationError =
                inventoryService.validate(
                        name,
                        quantity,
                        price,
                        category,
                        threshold
                );

        if (validationError != null) {

            Toast.makeText(
                    this,
                    validationError,
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        try {

            boolean updated =
                    inventoryService.updateItem(
                            itemId,
                            name,
                            quantity,
                            price,
                            category,
                            threshold
                    );

            if (updated) {

                Toast.makeText(
                        this,
                        "Item updated.",
                        Toast.LENGTH_SHORT
                ).show();

                finish();

            } else {

                Toast.makeText(
                        this,
                        "Update failed.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Could not update item. The name may already exist.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // Requires confirmation before permanently removing an inventory item.
    private void confirmDelete() {

        new AlertDialog.Builder(this)
                .setTitle("Delete item")
                .setMessage(
                        "Permanently delete this inventory item?"
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> deleteItem()
                )
                .setNegativeButton(
                        "Cancel",
                        null
                )
                .show();
    }

    // Removes the selected item through the service and shows the result.
    private void deleteItem() {

        try {

            boolean deleted =
                    inventoryService.deleteItem(itemId);

            if (deleted) {

                Toast.makeText(
                        this,
                        "Item deleted.",
                        Toast.LENGTH_SHORT
                ).show();

                finish();

            } else {

                Toast.makeText(
                        this,
                        "Delete failed.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Something went wrong while deleting the item.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // Displays the item's recorded quantity changes in a scrollable dialog.
    private void showItemHistory() {

        String history = reportRepository.getItemHistory(itemId);

        TextView historyText = new TextView(this);
        historyText.setText(history);
        historyText.setTextSize(15);
        historyText.setPadding(40, 30, 40, 30);
        historyText.setTextIsSelectable(true);

        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(historyText);

        new AlertDialog.Builder(this)
                .setTitle("Transaction History")
                .setView(scrollView)
                .setPositiveButton("Close", null)
                .show();
    }

}
