
package com.example.inventoryapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles reading and writing inventory data in the SQLite database.
 * Keeps database operations separate from the app's UI and business logic.
 */
public class InventoryRepository {

    private final DatabaseHelper databaseHelper;

    // Shared query for getting inventory items along with their category names.
    private static final String ITEM_SELECT =
            "SELECT i.id, i.item_name, i.quantity, i.price, " +
                    "c.name AS category, i.reorder_threshold, " +
                    "i.created_at, i.updated_at " +
                    "FROM inventory i " +
                    "JOIN categories c ON i.category_id = c.id ";

    public InventoryRepository(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    /**
     * Finds an existing category or creates it if needed.
     * Empty category names are replaced with General.
     */
    private long getOrCreateCategory(
            SQLiteDatabase db,
            String category) {

        String name = category.trim();

        if (name.isEmpty()) {
            name = "General";
        }

        try (Cursor cursor = db.rawQuery(
                "SELECT id FROM categories WHERE name=? COLLATE NOCASE",
                new String[]{name})) {

            if (cursor.moveToFirst()) {
                return cursor.getLong(0);
            }
        }

        ContentValues values = new ContentValues();
        values.put("name", name);

        long id = db.insertWithOnConflict(
                "categories", null, values,
                SQLiteDatabase.CONFLICT_IGNORE
        );

        if (id != -1) {
            return id;
        }

        try (Cursor cursor = db.rawQuery(
                "SELECT id FROM categories WHERE name=? COLLATE NOCASE",
                new String[]{name})) {

            if (cursor.moveToFirst()) {
                return cursor.getLong(0);
            }
        }

        throw new IllegalStateException("Category could not be created.");
    }

    // Converts an inventory item into values that can be saved to the database.
    private ContentValues toValues(
            InventoryItem item,
            long categoryId,
            long now) {

        ContentValues values = new ContentValues();

        values.put("item_name", item.getName());
        values.put("quantity", item.getQuantity());
        values.put("price", item.getPrice());
        values.put("category_id", categoryId);
        values.put("reorder_threshold", item.getReorderThreshold());
        values.put("updated_at", now);

        return values;
    }

    // Saves a record of quantity changes for the item's transaction history.
    private void recordTransaction(
            SQLiteDatabase db,
            long itemId,
            int change,
            String type,
            String note,
            long timestamp) {

        ContentValues values = new ContentValues();

        values.put("inventory_id", itemId);
        values.put("change_amount", change);
        values.put("type", type);
        values.put("note", note);
        values.put("created_at", timestamp);

        db.insertOrThrow("inventory_transactions", null, values);
    }

    /**
     * Adds a new inventory item and records its starting quantity.
     * Both operations use a transaction to keep the data consistent.
     */
    public long insert(InventoryItem item) {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        long now = System.currentTimeMillis();

        db.beginTransaction();

        try {
            long categoryId = getOrCreateCategory(
                    db, item.getCategory()
            );

            ContentValues values = toValues(
                    item, categoryId, now
            );

            values.put("created_at", now);
            values.put("is_active", 1);

            long itemId = db.insertOrThrow(
                    "inventory", null, values
            );

            recordTransaction(
                    db, itemId, item.getQuantity(),
                    "ADD", "Initial inventory quantity", now
            );

            db.setTransactionSuccessful();
            return itemId;

        } finally {
            db.endTransaction();
        }
    }

    /**
     * Updates an existing inventory item.
     * If the quantity changes, the difference is saved in transaction history.
     */
    public boolean update(InventoryItem item) {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        long now = System.currentTimeMillis();

        db.beginTransaction();

        try {
            int oldQuantity;

            try (Cursor cursor = db.rawQuery(
                    "SELECT quantity FROM inventory " +
                            "WHERE id=? AND is_active=1",
                    new String[]{String.valueOf(item.getId())})) {

                if (!cursor.moveToFirst()) {
                    return false;
                }

                oldQuantity = cursor.getInt(0);
            }

            long categoryId = getOrCreateCategory(
                    db, item.getCategory()
            );

            ContentValues values = toValues(
                    item, categoryId, now
            );

            int rows = db.update(
                    "inventory",
                    values,
                    "id=? AND is_active=1",
                    new String[]{String.valueOf(item.getId())}
            );

            if (rows != 1) {
                return false;
            }

            int change = item.getQuantity() - oldQuantity;

            if (change != 0) {
                String type = change > 0 ? "ADD" : "REMOVE";

                recordTransaction(
                        db, item.getId(), change,
                        type, "Quantity updated", now
                );
            }

            db.setTransactionSuccessful();
            return true;

        } finally {
            db.endTransaction();
        }
    }

    // Marks an item as inactive instead of permanently deleting its data.
    public boolean delete(long id) {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("is_active", 0);
        values.put("updated_at", System.currentTimeMillis());

        return db.update(
                "inventory",
                values,
                "id=? AND is_active=1",
                new String[]{String.valueOf(id)}
        ) == 1;
    }

    // Finds an active inventory item using its database ID.
    public InventoryItem getById(long id) {

        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                ITEM_SELECT + "WHERE i.id=? AND i.is_active=1",
                new String[]{String.valueOf(id)})) {

            if (cursor.moveToFirst()) {
                return fromCursor(cursor);
            }
        }

        return null;
    }

    // Returns all active inventory items, sorted alphabetically by name.
    public List<InventoryItem> getAll() {

        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                ITEM_SELECT +
                        "WHERE i.is_active=1 " +
                        "ORDER BY i.item_name COLLATE NOCASE",
                null)) {

            while (cursor.moveToNext()) {
                items.add(fromCursor(cursor));
            }
        }

        return items;
    }

    // Converts a database query result into an InventoryItem object.
    private InventoryItem fromCursor(Cursor cursor) {

        return new InventoryItem(
                cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                cursor.getString(cursor.getColumnIndexOrThrow("item_name")),
                cursor.getInt(cursor.getColumnIndexOrThrow("quantity")),
                cursor.getDouble(cursor.getColumnIndexOrThrow("price")),
                cursor.getString(cursor.getColumnIndexOrThrow("category")),
                cursor.getInt(cursor.getColumnIndexOrThrow("reorder_threshold")),
                cursor.getLong(cursor.getColumnIndexOrThrow("created_at")),
                cursor.getLong(cursor.getColumnIndexOrThrow("updated_at"))
        );
    }
}
