
package com.example.inventoryapp;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.PriorityQueue;

/**
 * Handles inventory business logic, including validation, searching,
 * sorting, stock summaries, and restock recommendations.
 * Keeps this logic separate from the UI and database operations.
 */
public class InventoryService {

    private final InventoryRepository repository;

    public InventoryService(InventoryRepository repository) {
        this.repository = repository;
    }

    // Keeps add/edit validation in one place instead of duplicating it in Activities.
    public String validate(
            String name,
            String quantityText,
            String priceText,
            String category,
            String thresholdText
    ) {

        if (name == null || name.trim().isEmpty()) {
            return "Item name is required.";
        }

        if (category == null || category.trim().isEmpty()) {
            return "Category is required.";
        }

        try {
            int quantity = Integer.parseInt(quantityText);

            if (quantity < 0) {
                return "Quantity cannot be negative.";
            }

        } catch (Exception e) {
            return "Quantity must be a whole number.";
        }

        try {
            double price = Double.parseDouble(priceText);

            if (!Double.isFinite(price) || price < 0) {
                return "Price must be a finite, non-negative number.";
            }

        } catch (Exception e) {
            return "Price must be a valid number.";
        }

        try {
            int threshold = Integer.parseInt(thresholdText);

            if (threshold < 0) {
                return "Reorder threshold cannot be negative.";
            }

        } catch (Exception e) {
            return "Reorder threshold must be a whole number.";
        }

        return null;
    }

    // Creates a new inventory item and passes it to the repository to save.
    public boolean addItem(
            String name,
            String quantityText,
            String priceText,
            String category,
            String thresholdText
    ) {

        InventoryItem item = new InventoryItem(
                name.trim(),
                Integer.parseInt(quantityText),
                Double.parseDouble(priceText),
                category.trim(),
                Integer.parseInt(thresholdText)
        );

        return repository.insert(item) != -1;
    }

    // Loads an existing item, updates its information, and saves the changes.
    public boolean updateItem(
            long id,
            String name,
            String quantityText,
            String priceText,
            String category,
            String thresholdText
    ) {

        InventoryItem existingItem = repository.getById(id);

        if (existingItem == null) {
            return false;
        }

        existingItem.setName(name.trim());
        existingItem.setQuantity(Integer.parseInt(quantityText));
        existingItem.setPrice(Double.parseDouble(priceText));
        existingItem.setCategory(category.trim());
        existingItem.setReorderThreshold(
                Integer.parseInt(thresholdText)
        );
        existingItem.setUpdatedAt(System.currentTimeMillis());

        return repository.update(existingItem);
    }

    public boolean deleteItem(long id) {
        return repository.delete(id);
    }

    public InventoryItem getItem(long id) {
        return repository.getById(id);
    }

    public List<InventoryItem> getAllItems() {
        return repository.getAll();
    }

    // Search, filtering, and sorting stay outside of the Activity.
    public List<InventoryItem> filterAndSort(
            List<InventoryItem> source,
            String query,
            String status,
            String sort
    ) {

        String normalizedQuery = query == null
                ? ""
                : query.trim().toLowerCase(Locale.US);

        List<InventoryItem> results = new ArrayList<>();

        // Only include items that match both the search and stock filter.
        for (InventoryItem item : source) {

            boolean matchesSearch =
                    item.getName()
                            .toLowerCase(Locale.US)
                            .contains(normalizedQuery)
                            ||
                            item.getCategory()
                                    .toLowerCase(Locale.US)
                                    .contains(normalizedQuery);

            boolean matchesStatus =
                    matchesStatus(item, status);

            if (matchesSearch && matchesStatus) {
                results.add(item);
            }
        }

        // Sort the matching items based on the user's selected option.
        if ("Quantity".equals(sort)) {

            results.sort(
                    Comparator.comparingInt(
                            InventoryItem::getQuantity
                    )
            );

        } else if ("Price".equals(sort)) {

            results.sort(
                    Comparator.comparingDouble(
                            InventoryItem::getPrice
                    )
            );

        } else if ("Restock priority".equals(sort)) {

            results.sort(
                    Comparator
                            .comparingInt(
                                    InventoryItem::getShortage
                            )
                            .reversed()
                            .thenComparing(
                                    InventoryItem::getName,
                                    String.CASE_INSENSITIVE_ORDER
                            )
            );

        } else {

            results.sort(
                    Comparator.comparing(
                            InventoryItem::getName,
                            String.CASE_INSENSITIVE_ORDER
                    )
            );
        }

        return results;
    }

    // Checks whether an item matches the selected stock status filter.
    private boolean matchesStatus(
            InventoryItem item,
            String status
    ) {

        if ("Needs restock".equals(status)) {
            return item.needsRestock();
        }

        if ("Out of stock".equals(status)) {
            return item.getQuantity() == 0;
        }

        if ("In stock".equals(status)) {
            return item.getQuantity()
                    > item.getReorderThreshold();
        }

        return true;
    }

    // Adds up the quantities of all items for the dashboard summary.
    public int getTotalUnits(
            List<InventoryItem> items
    ) {

        int total = 0;

        for (InventoryItem item : items) {
            total += item.getQuantity();
        }

        return total;
    }

    // Counts how many items have reached or fallen below their reorder threshold.
    public int getLowStockCount(
            List<InventoryItem> items
    ) {

        int count = 0;

        for (InventoryItem item : items) {

            if (item.needsRestock()) {
                count++;
            }
        }

        return count;
    }

    /*
     * Builds a ranked list of items that need restocking.
     *
     * PriorityQueue keeps the most urgent item at the head of the queue.
     * Larger shortages have higher priority. If two items have the same
     * shortage, lower current quantity wins the tie. Item name provides
     * a final deterministic tie-breaker.
     */
    public List<InventoryItem> getRestockRecommendations(
            List<InventoryItem> items
    ) {

        Comparator<InventoryItem> restockComparator =
                Comparator
                        .comparingInt(
                                InventoryItem::getShortage
                        )
                        .reversed()
                        .thenComparingInt(
                                InventoryItem::getQuantity
                        )
                        .thenComparing(
                                InventoryItem::getName,
                                String.CASE_INSENSITIVE_ORDER
                        );

        PriorityQueue<InventoryItem> priorityQueue =
                new PriorityQueue<>(restockComparator);

        // Add only items that are at or below their reorder threshold.
        for (InventoryItem item : items) {

            if (item.needsRestock()) {
                priorityQueue.offer(item);
            }
        }

        List<InventoryItem> recommendations =
                new ArrayList<>();

        // Remove items in priority order to build the final ranked list.
        while (!priorityQueue.isEmpty()) {
            recommendations.add(
                    priorityQueue.poll()
            );
        }

        return recommendations;
    }
}
