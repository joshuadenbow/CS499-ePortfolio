
package com.example.inventoryapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Handles database queries used to generate inventory reports.
 * Includes low stock, category summaries, recent changes, and item history.
 */
public class ReportRepository {

    private final DatabaseHelper databaseHelper;

    public ReportRepository(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    // Finds active items at or below their reorder threshold, ranked by shortage.
    public String getLowStockReport() {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        StringBuilder report = new StringBuilder("LOW STOCK REPORT\n\n");

        String sql =
                "SELECT i.item_name, i.quantity, " +
                        "i.reorder_threshold, c.name " +
                        "FROM inventory i " +
                        "JOIN categories c ON i.category_id = c.id " +
                        "WHERE i.is_active=1 " +
                        "AND i.quantity <= i.reorder_threshold " +
                        "ORDER BY (i.reorder_threshold - i.quantity) DESC, " +
                        "i.item_name COLLATE NOCASE";

        try (Cursor cursor = db.rawQuery(sql, null)) {
            if (!cursor.moveToFirst()) {
                return "No items currently need restocking.";
            }

            do {
                String name = cursor.getString(0);
                int quantity = cursor.getInt(1);
                int threshold = cursor.getInt(2);
                String category = cursor.getString(3);

                report.append(name).append("\n")
                        .append("Category: ").append(category).append("\n")
                        .append("Quantity: ").append(quantity).append("\n")
                        .append("Threshold: ").append(threshold).append("\n")
                        .append("Shortage: ")
                        .append(threshold - quantity).append("\n\n");

            } while (cursor.moveToNext());
        }

        return report.toString();
    }

    // Uses a JOIN and aggregate functions to summarize inventory by category.
    public String getCategorySummary() {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        StringBuilder report = new StringBuilder("CATEGORY SUMMARY\n\n");

        String sql =
                "SELECT c.name, COUNT(i.id), " +
                        "COALESCE(SUM(i.quantity), 0), " +
                        "COALESCE(SUM(i.quantity * i.price), 0) " +
                        "FROM categories c " +
                        "LEFT JOIN inventory i ON i.category_id = c.id " +
                        "AND i.is_active=1 " +
                        "GROUP BY c.id, c.name " +
                        "ORDER BY c.name COLLATE NOCASE";

        try (Cursor cursor = db.rawQuery(sql, null)) {
            while (cursor.moveToNext()) {
                report.append(cursor.getString(0)).append("\n")
                        .append("Items: ").append(cursor.getInt(1)).append("\n")
                        .append("Total units: ").append(cursor.getInt(2)).append("\n")
                        .append(String.format(
                                Locale.US,
                                "Inventory value: $%.2f\n\n",
                                cursor.getDouble(3)
                        ));
            }
        }

        return report.toString();
    }

    // Retrieves the 30 most recent inventory transactions and their details.
    public String getRecentChanges() {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        StringBuilder report =
                new StringBuilder("RECENT INVENTORY CHANGES\n\n");

        String sql =
                "SELECT i.item_name, t.change_amount, " +
                        "t.type, t.note, t.created_at " +
                        "FROM inventory_transactions t " +
                        "JOIN inventory i ON t.inventory_id = i.id " +
                        "ORDER BY t.created_at DESC, t.id DESC LIMIT 30";

        try (Cursor cursor = db.rawQuery(sql, null)) {
            if (!cursor.moveToFirst()) {
                return "No inventory changes have been recorded.";
            }

            do {
                int change = cursor.getInt(1);

                report.append(cursor.getString(0)).append("\n")
                        .append("Type: ").append(cursor.getString(2)).append("\n")
                        .append("Change: ")
                        .append(change > 0 ? "+" : "")
                        .append(change).append(" units\n")
                        .append("Note: ").append(cursor.getString(3)).append("\n")
                        .append("Date: ")
                        .append(formatDate(cursor.getLong(4)))
                        .append("\n\n");

            } while (cursor.moveToNext());
        }

        return report.toString();
    }

    // Retrieves the full transaction history for a specific inventory item.
    public String getItemHistory(long itemId) {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        StringBuilder report =
                new StringBuilder("ITEM TRANSACTION HISTORY\n\n");

        String sql =
                "SELECT type, change_amount, note, created_at " +
                        "FROM inventory_transactions " +
                        "WHERE inventory_id=? " +
                        "ORDER BY created_at DESC, id DESC";

        try (Cursor cursor = db.rawQuery(
                sql, new String[]{String.valueOf(itemId)})) {

            if (!cursor.moveToFirst()) {
                return "No transaction history for this item.";
            }

            do {
                int change = cursor.getInt(1);

                report.append(cursor.getString(0)).append(": ")
                        .append(change > 0 ? "+" : "")
                        .append(change).append(" units\n")
                        .append(cursor.getString(2)).append("\n")
                        .append(formatDate(cursor.getLong(3)))
                        .append("\n\n");

            } while (cursor.moveToNext());
        }

        return report.toString();
    }

    // Converts stored timestamps into readable dates for the reports.
    private String formatDate(long timestamp) {
        if (timestamp == 0) {
            return "Unknown date";
        }

        SimpleDateFormat formatter = new SimpleDateFormat(
                "MMM dd, yyyy h:mm a",
                Locale.getDefault()
        );

        return formatter.format(new Date(timestamp));
    }
}
