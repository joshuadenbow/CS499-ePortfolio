
package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import android.widget.ScrollView;
import androidx.appcompat.app.AlertDialog;

/**
 * Handles the main inventory dashboard and its controls.
 * Users can view, search, sort, and add inventory items here.
 * Also manages restock recommendations, reports, and SMS alerts.
 */
public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;

    private InventoryService inventoryService;
    private ReportRepository reportRepository;
    private InventoryAdapter inventoryAdapter;

    private RestockAdapter restockAdapter;

    private List<InventoryItem> allItems =
            new ArrayList<>();

    private EditText etItemName;
    private EditText etItemQuantity;
    private EditText etItemPrice;
    private EditText etItemCategory;
    private EditText etSearch;

    private EditText etItemThreshold;

    private Spinner spinnerFilter;
    private Spinner spinnerSort;

    private TextView tvItemCount;
    private TextView tvUnitCount;
    private TextView tvLowStockCount;
    private TextView tvEmptyState;
    private TextView tvNoRestockItems;
    private TextView tvSmsStatus;

    private boolean smsPermissionGranted;

    // Sets up the dashboard, database connections, and screen controls.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatabaseHelper databaseHelper =
                new DatabaseHelper(this);

        reportRepository =
                new ReportRepository(databaseHelper);

        InventoryRepository repository =
                new InventoryRepository(databaseHelper);

        inventoryService =
                new InventoryService(repository);

        bindViews();
        setupRecyclerView();
        setupControls();
        updateSmsStatus();
    }

    // Refreshes the dashboard after returning from the item detail screen.
    @Override
    protected void onResume() {
        super.onResume();

        if (inventoryService != null) {
            refreshInventory();
        }
    }

    // Connects the dashboard's input fields and labels to their XML views.
    private void bindViews() {

        etItemName =
                findViewById(R.id.etItemName);

        etItemQuantity =
                findViewById(R.id.etItemQuantity);

        etItemPrice =
                findViewById(R.id.etItemPrice);

        etItemCategory =
                findViewById(R.id.etItemCategory);

        etItemThreshold =
                findViewById(R.id.etItemThreshold);

        tvNoRestockItems =
                findViewById(R.id.tvNoRestockItems);

        etSearch =
                findViewById(R.id.etSearch);

        spinnerFilter =
                findViewById(R.id.spinnerFilter);

        spinnerSort =
                findViewById(R.id.spinnerSort);

        tvItemCount =
                findViewById(R.id.tvItemCount);

        tvUnitCount =
                findViewById(R.id.tvUnitCount);

        tvLowStockCount =
                findViewById(R.id.tvLowStockCount);

        tvEmptyState =
                findViewById(R.id.tvEmptyState);

        tvSmsStatus =
                findViewById(R.id.tvSmsStatus);
    }

    // Sets up the inventory and restock lists using RecyclerView adapters.
    private void setupRecyclerView() {

        RecyclerView recyclerInventory =
                findViewById(
                        R.id.recyclerInventory
                );

        recyclerInventory.setLayoutManager(
                new LinearLayoutManager(this)
        );

        inventoryAdapter =
                new InventoryAdapter(
                        item -> {

                            Intent intent =
                                    new Intent(
                                            MainActivity.this,
                                            ItemDetailActivity.class
                                    );

                            intent.putExtra(
                                    "item_id",
                                    item.getId()
                            );

                            startActivity(intent);
                        }
                );

        recyclerInventory.setAdapter(
                inventoryAdapter
        );

        RecyclerView recyclerRestock =
                findViewById(R.id.recyclerRestock);

        recyclerRestock.setLayoutManager(
                new LinearLayoutManager(this)
        );

        restockAdapter =
                new RestockAdapter();

        recyclerRestock.setAdapter(
                restockAdapter
        );
    }

    // Connects the search, sorting, filtering, and dashboard buttons.
    private void setupControls() {

        ArrayAdapter<String> filterAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        new String[]{
                                "All items",
                                "In stock",
                                "Needs restock",
                                "Out of stock"
                        }
                );

        filterAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerFilter.setAdapter(
                filterAdapter
        );

        ArrayAdapter<String> sortAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        new String[]{
                                "Name",
                                "Quantity",
                                "Price",
                                "Restock priority"
                        }
                );

        sortAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerSort.setAdapter(
                sortAdapter
        );

        AdapterView.OnItemSelectedListener selectionListener =
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        applyFilters();
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent
                    ) {
                        // No action is needed here.
                    }
                };

        spinnerFilter.setOnItemSelectedListener(
                selectionListener
        );

        spinnerSort.setOnItemSelectedListener(
                selectionListener
        );

        // Updates the visible inventory as the user types in the search bar.
        etSearch.addTextChangedListener(
                new TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after
                    ) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count
                    ) {
                        applyFilters();
                    }

                    @Override
                    public void afterTextChanged(
                            Editable s
                    ) {
                    }
                }
        );

        findViewById(R.id.btnAddItem)
                .setOnClickListener(
                        view -> addItem()
                );

        findViewById(R.id.btnSmsPermission)
                .setOnClickListener(
                        view -> checkSmsPermission()
                );

        // Each report button opens the matching database report.
        findViewById(R.id.btnLowStockReport)
                .setOnClickListener(view ->
                        showReport(
                                "Low Stock Report",
                                reportRepository.getLowStockReport()
                        )
                );

        findViewById(R.id.btnCategorySummary)
                .setOnClickListener(view ->
                        showReport(
                                "Category Summary",
                                reportRepository.getCategorySummary()
                        )
                );

        findViewById(R.id.btnRecentChanges)
                .setOnClickListener(view ->
                        showReport(
                                "Recent Changes",
                                reportRepository.getRecentChanges()
                        )
                );




    }

    // Validation and persistence are delegated to the service/repository layers.
    private void addItem() {

        String name =
                etItemName.getText()
                        .toString();

        String quantity =
                etItemQuantity.getText()
                        .toString();

        String price =
                etItemPrice.getText()
                        .toString();

        String category =
                etItemCategory.getText()
                        .toString();

        String threshold =
                etItemThreshold.getText()
                        .toString();

        String validationError =
                inventoryService.validate(
                        name,
                        quantity,
                        price,
                        category,
                        threshold
                );

        if (validationError != null) {

            Toast.makeText(
                    this,
                    validationError,
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        try {

            boolean added =
                    inventoryService.addItem(
                            name,
                            quantity,
                            price,
                            category,
                            threshold
                    );

            if (added) {

                Toast.makeText(
                        this,
                        "Item added.",
                        Toast.LENGTH_SHORT
                ).show();

                // Sends an alert if the new item is already low on stock.
                if (Integer.parseInt(quantity)
                        <= Integer.parseInt(threshold)) {

                    sendLowInventorySms(
                            name.trim()
                    );
                }

                clearAddForm();
                refreshInventory();

            } else {

                Toast.makeText(
                        this,
                        "Could not add item. The name may already exist.",
                        Toast.LENGTH_LONG
                ).show();
            }

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Something went wrong while saving the item.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // Clears the input fields after an item is successfully added.
    private void clearAddForm() {

        etItemName.setText("");
        etItemQuantity.setText("");
        etItemPrice.setText("");
        etItemCategory.setText("");
        etItemThreshold.setText("");
    }

    // Reloads the stored data and dashboard totals together.
    private void refreshInventory() {

        try {

            allItems =
                    inventoryService.getAllItems();

            List<InventoryItem> restockItems =
                    inventoryService
                            .getRestockRecommendations(allItems);

            restockAdapter.submitList(
                    restockItems
            );

            tvNoRestockItems.setVisibility(
                    restockItems.isEmpty()
                            ? View.VISIBLE
                            : View.GONE
            );

            tvItemCount.setText(
                    String.valueOf(
                            allItems.size()
                    )
            );

            tvUnitCount.setText(
                    String.valueOf(
                            inventoryService
                                    .getTotalUnits(
                                            allItems
                                    )
                    )
            );

            tvLowStockCount.setText(
                    String.valueOf(
                            inventoryService
                                    .getLowStockCount(
                                            allItems
                                    )
                    )
            );

            applyFilters();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Inventory could not be loaded.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // Applies the selected search, filter, and sort options to the inventory list.
    private void applyFilters() {

        if (inventoryAdapter == null
                || spinnerFilter.getSelectedItem() == null
                || spinnerSort.getSelectedItem() == null) {
            return;
        }

        List<InventoryItem> visibleItems =
                inventoryService.filterAndSort(
                        allItems,
                        etSearch.getText()
                                .toString(),
                        spinnerFilter
                                .getSelectedItem()
                                .toString(),
                        spinnerSort
                                .getSelectedItem()
                                .toString()
                );

        inventoryAdapter.submitList(
                visibleItems
        );

        tvEmptyState.setVisibility(
                visibleItems.isEmpty()
                        ? View.VISIBLE
                        : View.GONE
        );
    }

    // Checks whether the app currently has permission to send SMS alerts.
    private void updateSmsStatus() {

        smsPermissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                )
                        == PackageManager.PERMISSION_GRANTED;

        tvSmsStatus.setText(
                smsPermissionGranted
                        ? "SMS permission granted."
                        : "SMS permission not granted."
        );
    }

    // Requests SMS permission if it has not already been granted.
    private void checkSmsPermission() {

        if (!smsPermissionGranted) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.SEND_SMS
                    },
                    SMS_PERMISSION_CODE
            );

        } else {

            Toast.makeText(
                    this,
                    "SMS already enabled.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Updates the permission status after the user responds to the request.
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode
                == SMS_PERMISSION_CODE) {

            smsPermissionGranted =
                    grantResults.length > 0
                            && grantResults[0]
                            == PackageManager
                            .PERMISSION_GRANTED;

            updateSmsStatus();
        }
    }

    // Preserves the original zero-stock SMS behavior.
    private void sendLowInventorySms(
            String itemName
    ) {

        if (!smsPermissionGranted) {
            return;
        }

        try {

            SmsManager.getDefault()
                    .sendTextMessage(
                            "5551234567",
                            null,
                            "Inventory alert: "
                                    + itemName
                                    + " is out of stock.",
                            null,
                            null
                    );

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "SMS notification could not be sent.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Shows a database report in a scrollable dialog.
    private void showReport(String title, String content) {

        TextView reportText = new TextView(this);
        reportText.setText(content);
        reportText.setTextSize(15);
        reportText.setPadding(40, 30, 40, 30);
        reportText.setTextIsSelectable(true);

        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(reportText);

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(scrollView)
                .setPositiveButton("Close", null)
                .show();
    }

}
