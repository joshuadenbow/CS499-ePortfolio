
package com.example.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Handles displaying inventory items in the RecyclerView.
 * Each item shows its details and current stock status.
 */
public class InventoryAdapter
        extends RecyclerView.Adapter<InventoryAdapter.ItemViewHolder> {

    // Passes the selected item back when a user taps an inventory card.
    public interface OnItemClickListener {
        void onItemClick(InventoryItem item);
    }

    private final List<InventoryItem> items = new ArrayList<>();
    private final OnItemClickListener listener;

    public InventoryAdapter(OnItemClickListener listener) {
        this.listener = listener;
    }

    // Refreshes the cards whenever the visible inventory changes.
    public void submitList(List<InventoryItem> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    // Creates the layout used for each inventory card.
    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {

        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(
                        R.layout.item_inventory,
                        parent,
                        false
                );

        return new ItemViewHolder(view);
    }

    // Fills each card with item information and its stock status.
    @Override
    public void onBindViewHolder(
            @NonNull ItemViewHolder holder,
            int position
    ) {

        InventoryItem item = items.get(position);

        holder.name.setText(item.getName());

        String details =
                item.getCategory()
                        + " • Qty: "
                        + item.getQuantity()
                        + " • Threshold: "
                        + item.getReorderThreshold()
                        + " • "
                        + String.format(
                        Locale.US,
                        "$%.2f",
                        item.getPrice()
                );

        holder.details.setText(details);

        // Show a different message depending on the item's stock level.
        if (item.getQuantity() == 0) {

            holder.status.setText(
                    "Out of stock • Restock "
                            + item.getShortage()
                            + " units"
            );

        } else if (item.needsRestock()) {

            holder.status.setText(
                    "Needs restock • Shortage: "
                            + item.getShortage()
            );

        } else {

            holder.status.setText("In stock");
        }

        holder.itemView.setOnClickListener(
                view -> listener.onItemClick(item)
        );
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // ViewHolder lets RecyclerView efficiently reuse the same card layout.
    static class ItemViewHolder
            extends RecyclerView.ViewHolder {

        final TextView name;
        final TextView details;
        final TextView status;

        ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            name =
                    itemView.findViewById(
                            R.id.tvItemName
                    );

            details =
                    itemView.findViewById(
                            R.id.tvItemDetails
                    );

            status =
                    itemView.findViewById(
                            R.id.tvItemStatus
                    );
        }
    }
}
