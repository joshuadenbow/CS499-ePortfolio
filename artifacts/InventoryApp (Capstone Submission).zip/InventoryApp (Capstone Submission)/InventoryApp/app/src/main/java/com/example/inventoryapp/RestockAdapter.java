
package com.example.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Displays prioritized restock recommendations in a RecyclerView.
 * Shows each item's rank, quantity, reorder threshold, and shortage.
 */
public class RestockAdapter
        extends RecyclerView.Adapter<RestockAdapter.RestockViewHolder> {

    private final List<InventoryItem> items =
            new ArrayList<>();

    // Updates the displayed recommendations when the restock list changes.
    public void submitList(
            List<InventoryItem> newItems
    ) {

        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    // Creates a new ViewHolder using the restock recommendation layout.
    @NonNull
    @Override
    public RestockViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {

        View view =
                LayoutInflater
                        .from(parent.getContext())
                        .inflate(
                                R.layout.item_restock_recommendation,
                                parent,
                                false
                        );

        return new RestockViewHolder(view);
    }

    // Fills each recommendation with its priority and inventory details.
    @Override
    public void onBindViewHolder(
            @NonNull RestockViewHolder holder,
            int position
    ) {

        InventoryItem item =
                items.get(position);

        holder.rank.setText(
                "Priority #" + (position + 1)
        );

        holder.name.setText(
                item.getName()
        );

        holder.details.setText(
                "Qty: "
                        + item.getQuantity()
                        + " • Threshold: "
                        + item.getReorderThreshold()
                        + " • "
                        + item.getCategory()
        );

        holder.shortage.setText(
                "Shortage: "
                        + item.getShortage()
                        + " units"
        );
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // Holds the text views used for each restock recommendation.
    static class RestockViewHolder
            extends RecyclerView.ViewHolder {

        final TextView rank;
        final TextView name;
        final TextView details;
        final TextView shortage;

        RestockViewHolder(
                @NonNull View itemView
        ) {
            super(itemView);

            rank =
                    itemView.findViewById(
                            R.id.tvRestockRank
                    );

            name =
                    itemView.findViewById(
                            R.id.tvRestockName
                    );

            details =
                    itemView.findViewById(
                            R.id.tvRestockDetails
                    );

            shortage =
                    itemView.findViewById(
                            R.id.tvRestockShortage
                    );
        }
    }
}
