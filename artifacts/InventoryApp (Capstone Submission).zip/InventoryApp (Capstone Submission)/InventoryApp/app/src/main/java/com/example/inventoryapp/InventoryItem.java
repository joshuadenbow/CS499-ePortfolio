
package com.example.inventoryapp;

/**
 * Represents an individual inventory item and its information.
 * Also includes basic logic for checking when an item needs restocking.
 */
public class InventoryItem {

    private final long id;
    private String name;
    private int quantity;
    private double price;
    private String category;
    private int reorderThreshold;
    private final long createdAt;
    private long updatedAt;

    // Used when an existing inventory item is loaded from the database.
    public InventoryItem(
            long id,
            String name,
            int quantity,
            double price,
            String category,
            int reorderThreshold,
            long createdAt,
            long updatedAt
    ) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.price = price;
        this.category = category;
        this.reorderThreshold = reorderThreshold;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Used when the user creates a brand-new inventory item.
    public InventoryItem(
            String name,
            int quantity,
            double price,
            String category,
            int reorderThreshold
    ) {
        this(
                0,
                name,
                quantity,
                price,
                category,
                reorderThreshold,
                System.currentTimeMillis(),
                System.currentTimeMillis()
        );
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getReorderThreshold() {
        return reorderThreshold;
    }

    public void setReorderThreshold(int reorderThreshold) {
        this.reorderThreshold = reorderThreshold;
    }

    // Positive values indicate how many units below the threshold the item is.
    public int getShortage() {
        return reorderThreshold - quantity;
    }

    // Checks if the item's quantity has reached or fallen below its threshold.
    public boolean needsRestock() {
        return quantity <= reorderThreshold;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(long updatedAt) {
        this.updatedAt = updatedAt;
    }
}
