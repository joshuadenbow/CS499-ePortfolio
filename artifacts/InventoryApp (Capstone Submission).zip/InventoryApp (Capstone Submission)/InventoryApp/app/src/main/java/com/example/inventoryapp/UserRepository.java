
package com.example.inventoryapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Handles user account creation and authentication through SQLite.
 * Uses salted password hashes to avoid storing passwords as plain text.
 */
public class UserRepository {

    private final DatabaseHelper databaseHelper;

    public UserRepository(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    // Creates an account without storing the user's original password.
    public boolean createUser(String username, String password) {

        String salt = PasswordUtils.generateSalt();
        String passwordHash =
                PasswordUtils.hashPassword(password, salt);

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password_hash", passwordHash);
        values.put("password_salt", salt);

        long result = databaseHelper
                .getWritableDatabase()
                .insert("users", null, values);

        return result != -1;
    }

    // Looks up the account and compares password hashes during login.
    public boolean authenticate(String username, String password) {

        SQLiteDatabase db =
                databaseHelper.getReadableDatabase();

        try (Cursor cursor = db.query(
                "users",
                new String[]{
                        "password_hash",
                        "password_salt"
                },
                "username=?",
                new String[]{username},
                null,
                null,
                null
        )) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            String expectedHash = cursor.getString(0);
            String salt = cursor.getString(1);

            String suppliedHash =
                    PasswordUtils.hashPassword(
                            password,
                            salt
                    );

            return expectedHash.equals(suppliedHash);
        }
    }
}
