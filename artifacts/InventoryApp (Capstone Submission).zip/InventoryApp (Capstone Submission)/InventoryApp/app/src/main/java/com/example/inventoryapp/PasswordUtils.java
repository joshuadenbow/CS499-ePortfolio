
package com.example.inventoryapp;

import android.util.Base64;

import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Provides password hashing and salt generation for user accounts.
 * Helps keep passwords secure without storing them as plain text.
 */
public final class PasswordUtils {

    private static final int ITERATIONS = 120000;
    private static final int KEY_LENGTH = 256;

    private PasswordUtils() {
        // Utility class only, so it should not be instantiated.
    }

    // Generates a unique random salt for each account.
    public static String generateSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    // Hashes a password with PBKDF2 instead of storing the original password.
    public static String hashPassword(String password, String saltText) {

        try {
            byte[] salt = Base64.decode(saltText, Base64.NO_WRAP);

            PBEKeySpec specification = new PBEKeySpec(
                    password.toCharArray(),
                    salt,
                    ITERATIONS,
                    KEY_LENGTH
            );

            byte[] hash = SecretKeyFactory
                    .getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(specification)
                    .getEncoded();

            specification.clearPassword();

            return Base64.encodeToString(hash, Base64.NO_WRAP);

        } catch (Exception e) {
            throw new IllegalStateException(
                    "Unable to hash password.",
                    e
            );
        }
    }
}
