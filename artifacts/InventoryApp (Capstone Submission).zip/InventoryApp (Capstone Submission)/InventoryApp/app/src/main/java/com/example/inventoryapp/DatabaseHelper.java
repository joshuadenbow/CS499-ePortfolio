
package com.example.inventoryapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Handles creating and upgrading the app's SQLite database.
 * Also sets up the tables and relationships used to store inventory data.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_app.db";
    private static final int DATABASE_VERSION = 4;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Enables foreign keys so relationships between tables are enforced.
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    // Creates the database tables when the app is first installed.
    @Override
    public void onCreate(SQLiteDatabase db) {
        createTables(db);
    }

    /**
     * Sets up the four database tables, their constraints, and indexes.
     * A default General category is also added for inventory items.
     */
    private void createTables(SQLiteDatabase db) {

        // Stores user accounts, password information, and roles.
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password_hash TEXT NOT NULL, " +
                        "password_salt TEXT NOT NULL, " +
                        "role TEXT NOT NULL DEFAULT 'USER' " +
                        "CHECK(role IN ('USER','ADMIN')), " +
                        "created_at INTEGER NOT NULL DEFAULT 0)"
        );

        // Keeps categories separate from inventory to avoid duplicate data.
        db.execSQL(
                "CREATE TABLE categories (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL COLLATE NOCASE UNIQUE " +
                        "CHECK(length(trim(name)) > 0))"
        );

        // Stores inventory items along with quantities and reorder thresholds.
        db.execSQL(
                "CREATE TABLE inventory (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "item_name TEXT NOT NULL UNIQUE, " +
                        "quantity INTEGER NOT NULL CHECK(quantity >= 0), " +
                        "price REAL NOT NULL CHECK(price >= 0), " +
                        "category_id INTEGER NOT NULL, " +
                        "reorder_threshold INTEGER NOT NULL DEFAULT 5 " +
                        "CHECK(reorder_threshold >= 0), " +
                        "created_at INTEGER NOT NULL, " +
                        "updated_at INTEGER NOT NULL, " +
                        "is_active INTEGER NOT NULL DEFAULT 1 " +
                        "CHECK(is_active IN (0,1)), " +
                        "FOREIGN KEY(category_id) REFERENCES categories(id))"
        );

        // Tracks changes to inventory quantities for transaction history.
        db.execSQL(
                "CREATE TABLE inventory_transactions (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "inventory_id INTEGER NOT NULL, " +
                        "change_amount INTEGER NOT NULL, " +
                        "type TEXT NOT NULL " +
                        "CHECK(type IN ('ADD','REMOVE','ADJUST')), " +
                        "note TEXT NOT NULL DEFAULT '', " +
                        "created_at INTEGER NOT NULL, " +
                        "FOREIGN KEY(inventory_id) REFERENCES inventory(id))"
        );

        // Indexes help speed up category lookups and transaction reports.
        db.execSQL(
                "CREATE INDEX idx_inventory_category " +
                        "ON inventory(category_id)"
        );

        db.execSQL(
                "CREATE INDEX idx_transactions_item_date " +
                        "ON inventory_transactions(inventory_id, created_at)"
        );

        db.execSQL(
                "CREATE INDEX idx_transactions_date " +
                        "ON inventory_transactions(created_at)"
        );

        db.execSQL(
                "INSERT INTO categories(name) VALUES ('General')"
        );
    }

    /**
     * Handles database upgrades when the version number changes.
     * Version 3 data is migrated into the newer database structure.
     */
    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        if (oldVersion == 3) {
            migrateFromVersion3(db);
        } else {
            throw new IllegalStateException(
                    "Unsupported database upgrade from version " +
                            oldVersion
            );
        }
    }

    /**
     * Moves existing version 3 data into the updated database tables.
     * This keeps user accounts and inventory items from being lost.
     */
    private void migrateFromVersion3(SQLiteDatabase db) {

        // Rename the old tables so their data can be copied over.
        db.execSQL("ALTER TABLE users RENAME TO users_old");
        db.execSQL("ALTER TABLE inventory RENAME TO inventory_old");

        createTables(db);

        // Copy existing users into the new users table.
        db.execSQL(
                "INSERT INTO users " +
                        "(id, username, password_hash, password_salt, role, created_at) " +
                        "SELECT id, username, password_hash, password_salt, " +
                        "'USER', 0 FROM users_old"
        );

        // Move existing category names into the new categories table.
        db.execSQL(
                "INSERT OR IGNORE INTO categories(name) " +
                        "SELECT DISTINCT COALESCE(NULLIF(trim(category), ''), 'General') " +
                        "FROM inventory_old"
        );

        // Copy inventory items and connect them to their category IDs.
        db.execSQL(
                "INSERT INTO inventory " +
                        "(id, item_name, quantity, price, category_id, " +
                        "reorder_threshold, created_at, updated_at, is_active) " +
                        "SELECT i.id, i.item_name, i.quantity, i.price, " +
                        "c.id, i.reorder_threshold, i.created_at, " +
                        "i.updated_at, 1 " +
                        "FROM inventory_old i " +
                        "JOIN categories c ON c.name = " +
                        "COALESCE(NULLIF(trim(i.category), ''), 'General') " +
                        "COLLATE NOCASE"
        );

        // Record the starting quantities so migrated items have a history entry.
        db.execSQL(
                "INSERT INTO inventory_transactions " +
                        "(inventory_id, change_amount, type, note, created_at) " +
                        "SELECT id, quantity, 'ADD', " +
                        "'Migrated opening balance', updated_at " +
                        "FROM inventory"
        );

        // Remove the old tables once the migration is finished.
        db.execSQL("DROP TABLE inventory_old");
        db.execSQL("DROP TABLE users_old");
    }
}
