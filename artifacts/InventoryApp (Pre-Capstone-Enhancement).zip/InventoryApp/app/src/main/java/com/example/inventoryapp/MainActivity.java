package com.example.inventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;

    private TableLayout tableInventory;
    private EditText etItemName;
    private EditText etItemQuantity;
    private Button btnAddItem;
    private Button btnSmsPermission;
    private TextView tvSmsStatus;

    private DatabaseHelper databaseHelper;
    private boolean smsPermissionGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tableInventory = findViewById(R.id.tableInventory);
        etItemName = findViewById(R.id.etItemName);
        etItemQuantity = findViewById(R.id.etItemQuantity);
        btnAddItem = findViewById(R.id.btnAddItem);
        btnSmsPermission = findViewById(R.id.btnSmsPermission);
        tvSmsStatus = findViewById(R.id.tvSmsStatus);

        databaseHelper = new DatabaseHelper(this);

        updateSmsStatus();
        loadInventoryData();

        btnAddItem.setOnClickListener(v -> {
            String itemName = etItemName.getText().toString().trim();
            String quantityText = etItemQuantity.getText().toString().trim();

            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity;
            try {
                quantity = Integer.parseInt(quantityText);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted = databaseHelper.insertItem(itemName, quantity);

            if (inserted) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                etItemName.setText("");
                etItemQuantity.setText("");
                loadInventoryData();

                if (quantity == 0) {
                    sendLowInventorySms(itemName);
                }
            } else {
                Toast.makeText(this, "Item may already exist", Toast.LENGTH_SHORT).show();
            }
        });

        btnSmsPermission.setOnClickListener(v -> checkSmsPermission());
    }

    private void loadInventoryData() {
        while (tableInventory.getChildCount() > 1) {
            tableInventory.removeViewAt(1);
        }

        List<String[]> items = databaseHelper.getAllItems();

        for (String[] item : items) {
            String itemName = item[0];
            String itemQuantity = item[1];

            TableRow row = new TableRow(this);

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setLayoutParams(new TableRow.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            deleteButton.setOnClickListener(v -> showDeleteDialog(itemName));

            TextView nameView = new TextView(this);
            nameView.setText(itemName);
            nameView.setPadding(16, 16, 16, 16);
            nameView.setBackgroundColor(0xFFEFEFEF);
            nameView.setLayoutParams(new TableRow.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2));

            TextView quantityView = new TextView(this);
            quantityView.setText(itemQuantity);
            quantityView.setPadding(16, 16, 16, 16);
            quantityView.setBackgroundColor(0xFFEFEFEF);
            quantityView.setLayoutParams(new TableRow.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

            Button editButton = new Button(this);
            editButton.setText("Edit Qty");
            editButton.setLayoutParams(new TableRow.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            editButton.setOnClickListener(v -> showEditQuantityDialog(itemName, itemQuantity));

            row.addView(deleteButton);
            row.addView(nameView);
            row.addView(quantityView);
            row.addView(editButton);

            tableInventory.addView(row);
        }
    }

    private void showDeleteDialog(String itemName) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Delete \"" + itemName + "\"?")
                .setPositiveButton("Yes", (d, w) -> {
                    databaseHelper.deleteItem(itemName);
                    loadInventoryData();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void showEditQuantityDialog(String itemName, String currentQuantity) {
        EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setText(currentQuantity);

        new AlertDialog.Builder(this)
                .setTitle("Edit Quantity")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    int newQty = Integer.parseInt(input.getText().toString());
                    databaseHelper.updateItemQuantity(itemName, newQty);
                    loadInventoryData();

                    if (newQty == 0) {
                        sendLowInventorySms(itemName);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updateSmsStatus() {
        smsPermissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        tvSmsStatus.setText(smsPermissionGranted ?
                "SMS permission granted." :
                "SMS permission not granted.");
    }

    private void checkSmsPermission() {
        if (!smsPermissionGranted) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        } else {
            Toast.makeText(this, "SMS already enabled", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] p, int[] g) {
        super.onRequestPermissionsResult(requestCode, p, g);

        if (requestCode == SMS_PERMISSION_CODE) {
            smsPermissionGranted = g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED;
            updateSmsStatus();
        }
    }

    private void sendLowInventorySms(String itemName) {
        if (!smsPermissionGranted) return;

        try {
            SmsManager.getDefault().sendTextMessage(
                    "5551234567",
                    null,
                    "Inventory alert: " + itemName + " is out of stock.",
                    null,
                    null
            );
            Toast.makeText(this, "SMS triggered", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed", Toast.LENGTH_SHORT).show();
        }
    }
}